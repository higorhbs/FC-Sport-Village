/* Funções dos Botões */
function cancelar () {
    alert("Seu formulário foi cancelado")
    }

function salvar () {
    alert("Seu formulário foi salvo")
    }

function enviar () {
    alert("Seu formulário foi salvo e publicado")
    }
/* Fim das funções dos Botões */